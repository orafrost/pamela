master_doc = 'pam_python'
project = u'pam_python'
copyright = u'2010,2014,2016, Russell Stuart'
version = '1.0.6'
release = '1.0.6'
extensions = ['sphinx.ext.intersphinx']
intersphinx_mapping = {'python': ('http://docs.python.org/2.7', None)}
